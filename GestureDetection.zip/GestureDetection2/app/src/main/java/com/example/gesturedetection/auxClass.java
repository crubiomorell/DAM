package com.example.gesturedetection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class auxClass extends AppCompatActivity {
    private static final String LOG_TAG = com.example.gesturedetection.auxClass.class.getSimpleName();

    public void onButtonClick(View v) {
        startActivity(new Intent(com.example.gesturedetection.auxClass.this, MainActivity.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("auxClass","Resumed");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("auxClass","Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("auxClass","Destroyed");
        Log.d(LOG_TAG, "auxClass ended");
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auxclass);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("auxClass","Paused");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("auxClass","Resumed");
    }
}