package com.example.gesturedetection;

import static com.example.gesturedetection.R.id.relativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity<onSwipeTouchListener> extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        onSwipeTouchListener onSwipeTouchListener = (onSwipeTouchListener) new OnSwipeTouchListener(this, findViewById(relativeLayout));
    }

    public void onButtonClick(View v) {
        startActivity(new Intent(MainActivity.this, auxClass.class));
    }

    public static class OnSwipeTouchListener implements View.OnTouchListener {
        private final GestureDetector gD;
        Context contexto;


        OnSwipeTouchListener(Context contexto, View mainView) {
            gD = new GestureDetector(contexto, new GestureListener());
            mainView.setOnTouchListener(this);
            this.contexto = contexto;
        }



        //Creación de la clase gestureListener que extiende su clase padre SimpleOn
        public class GestureListener extends
                GestureDetector.SimpleOnGestureListener {

            private static final int S_THRESHOLD = 150;
            private static final int S_VEL_TH = 5;


            @Override
            public boolean onFling(MotionEvent m1, MotionEvent m2, float vel1, float vel2) {
                boolean res = false;
                try {

                    float diff1 = m2.getX() - m1.getX();
                    float diff2 = m2.getY() - m1.getY();

                    if (Math.abs(diff1) > Math.abs(diff2)) {
                        if (Math.abs(vel1) > S_VEL_TH  && Math.abs(diff1) > S_THRESHOLD) {
                            if (diff2 < 100 && diff2 > -100){
                                if (diff1 > 0) {
                                    onSwipeRight();
                                } else {
                                    onSwipeLeft();
                                }
                                res = true;
                            }
                            else {
                                Toast.makeText(contexto, "No se ha detectado el movimiento correctamente", Toast.LENGTH_SHORT).show();
                            }


                        }
                    }
                    else if (Math.abs(diff2) > S_THRESHOLD && Math.abs(vel2) > S_VEL_TH) {


                        if (diff1 < 100 && diff1 > -100) {
                            if (diff2 > 0) {
                                onSwipeBottom();
                            } else {
                                onSwipeTop();
                            }
                            res = true;
                        }
                        else {
                            Toast.makeText(contexto, "No se ha detectado el movimiento correctamente", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                return res;
            }
        }


        public boolean onDown(MotionEvent e) {
            return true;
        }

        void onSwipeTop() {
            Toast.makeText(contexto, "Arriba", Toast.LENGTH_SHORT).show();
            this.onSwipe.swipeTop();
        }

        void onSwipeBottom() {
            Toast.makeText(contexto, "Abajo", Toast.LENGTH_SHORT).show();
            this.onSwipe.swipeBottom();
        }

        void onSwipeLeft() {
            Toast.makeText(contexto, "Izquierda", Toast.LENGTH_SHORT).show();
            this.onSwipe.swipeLeft();
        }

        void onSwipeRight() {
            Toast.makeText(contexto, "Derecha", Toast.LENGTH_SHORT).show();
            this.onSwipe.swipeRight();

        }

        interface onSwipeListener {
            void swipeBottom();
            void swipeTop();
            void swipeRight();
            void swipeLeft();
        }
        onSwipeListener onSwipe;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            return gD.onTouchEvent(event);
        }
    }

}











    }

    //ONSWIPETOUCH listener de la interfaz Vies.OnTouchListener



}