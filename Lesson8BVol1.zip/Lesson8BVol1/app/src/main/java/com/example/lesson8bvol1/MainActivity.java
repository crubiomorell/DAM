package com.example.lesson8bvol1;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class MainActivity extends AppCompatActivity{
    TextView sc1;
    TextView sc2;
    int score1;
    int score2;
    Toast limite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sc1 = (TextView) findViewById(R.id.score1);
        sc2 = (TextView) findViewById(R.id.score2);
        if (savedInstanceState != null) {
            score1 = savedInstanceState.getInt("STATE_SCORE_1");
            score2 = savedInstanceState.getInt("STATE_SCORE_2");
            sc1.setText(String.valueOf(score1));
            sc2.setText(String.valueOf(score2));
        }
        limite = Toast.makeText(this, "Se ha alcanzado el límite", Toast.LENGTH_SHORT);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        outState.putInt("STATE_SCORE1", score1);
        outState.putInt("STATE_SCORE2", score2);
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        int nightMode = AppCompatDelegate.getDefaultNightMode();
        if(nightMode == AppCompatDelegate.MODE_NIGHT_YES){
            menu.findItem(R.id.night_mode).setTitle(R.string.day_mode);
        } else{
            menu.findItem(R.id.night_mode).setTitle(R.string.night_mode);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.night_mode){
            int nightMode = AppCompatDelegate.getDefaultNightMode();
            if(nightMode == AppCompatDelegate.MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                recreate();
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                recreate();
            }
        }
        return true;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add1:
                if (sc1.getText().toString().equals("75")) {
                    limite.show();
                } else {
                    sc1.setText(String.valueOf(Integer.parseInt(sc1.getText().toString()) + 1));
                }
                break;
            case R.id.add2:
                if (sc2.getText().toString().equals("75")) {
                    limite.show();
                } else {
                    sc2.setText(String.valueOf(Integer.parseInt(sc2.getText().toString()) + 1));
                }
                break;
            case R.id.minus1:
                if (sc1.getText().toString().equals("0")) {
                    limite.show();
                } else {
                    sc1.setText(String.valueOf(Integer.parseInt(sc1.getText().toString()) - 1));
                }
                break;
            case R.id.minus2:
                if (sc2.getText().toString().equals("0")) {
                    limite.show();
                } else {
                    sc2.setText(String.valueOf(Integer.parseInt(sc2.getText().toString()) - 1));
                }
                break;
        }
    }

}
