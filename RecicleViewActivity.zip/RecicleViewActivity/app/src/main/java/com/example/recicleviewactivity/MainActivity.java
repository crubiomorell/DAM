package com.example.recicleviewactivity;


import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.RecicleViewActivity.R;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity{
    RecyclerView mRecyclerView;
    WordListAdapter mAdapter;
    LinkedList<String> mWordList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWordList = new LinkedList<String>();
        for (int i = 0 ; i <= 10; i++) {
            mWordList.addLast(getString(R.string.text) + " " + i);
        }
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, mWordList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void onClick(View v) {
        mWordList.addLast("+ "+ getString(R.string.text) + " " + mWordList.size());
        mRecyclerView.getAdapter().notifyItemInserted(mWordList.size());
        mRecyclerView.smoothScrollToPosition(mWordList.size());
    }

}